
#ifndef _SPI_H
#define _SPI_H

// Function prototypes
unsigned int SPI_init(void);
char SPI_write(char data);
char SPI_read(void);

#endif
